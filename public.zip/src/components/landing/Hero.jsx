import {
  Box,
  Button,
  Container,
  Grid,
  Stack,
  Typography,
  Chip
} from "@mui/material";

import {
  ArrowForward,
  HealthAndSafety,

} from "@mui/icons-material";
import PlayCircleIcon from "@mui/icons-material/PlayCircle";
import { motion } from "framer-motion";

import FamilyImage from "../../assets/images/welcome1.jpg";

export default function Hero() {
  return (
    <Box
      sx={{
        minHeight: "100vh",
        background:
          "linear-gradient(to right,#ffffff,#eef6ff)",
        display: "flex",
        alignItems: "center",
      }}
    >
      <Container maxWidth="xl">

        <Grid container spacing={6} alignItems="center">

          {/* LEFT SIDE */}

          <Grid size={{ xs: 12, md: 6 }}>

            <motion.div
              initial={{ x: -80, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: .8 }}
            >

              <Chip
                icon={<HealthAndSafety />}
                label="AI Powered Healthcare Platform"
                sx={{
                  mb: 3,
                  borderRadius: 5,
                  px: 1
                }}
              />

              <Typography
                variant="h2"
                fontWeight="bold"
                lineHeight={1.2}
              >
                Your Health.
                <br />

                <Box
                  component="span"
                  color="primary.main"
                >
                  Connected.
                </Box>

                <br />

                Intelligent.
              </Typography>

              <Typography
                sx={{
                  mt: 3,
                  color: "#555",
                  fontSize: 18,
                  lineHeight: 1.8
                }}
              >
                Store your medical records securely,
                analyze symptoms using AI,
                connect with hospitals,
                and manage your family's health
                in one platform.
              </Typography>

              <Stack
                direction="row"
                spacing={2}
                sx={{ mt: 4 }}
              >

                <Button
                  variant="contained"
                  size="large"
                  endIcon={<ArrowForward />}
                  sx={{
                    borderRadius: 8,
                    px: 4,
                    py: 1.5
                  }}
                >
                  Let's Start
                </Button>

                <Button
                  variant="outlined"
                  size="large"
                  startIcon={<PlayCircleIcon />}
                  sx={{
                    borderRadius: 8,
                    px: 4,
                    py: 1.5
                  }}
                >
                  Watch Demo
                </Button>

              </Stack>

              <Grid
                container
                spacing={3}
                sx={{ mt: 5 }}
              >

                <Grid size={{ xs: 6, md: 3 }}>
                  <Typography variant="h5" fontWeight="bold">
                    10K+
                  </Typography>

                  <Typography color="text.secondary">
                    Health Records
                  </Typography>
                </Grid>

                <Grid size={{ xs: 6, md: 3 }}>
                  <Typography variant="h5" fontWeight="bold">
                    98%
                  </Typography>

                  <Typography color="text.secondary">
                    Security
                  </Typography>
                </Grid>

                <Grid size={{ xs: 6, md: 3 }}>
                  <Typography variant="h5" fontWeight="bold">
                    24/7
                  </Typography>

                  <Typography color="text.secondary">
                    Support
                  </Typography>
                </Grid>

                <Grid size={{ xs: 6, md: 3 }}>
                  <Typography variant="h5" fontWeight="bold">
                    15+
                  </Typography>

                  <Typography color="text.secondary">
                    Health Parameters
                  </Typography>
                </Grid>

              </Grid>

            </motion.div>

          </Grid>

          {/* RIGHT SIDE */}

          <Grid size={{ xs: 12, md: 6 }}>

            <motion.img
              src={FamilyImage}
              alt="family"
              style={{
                width: "100%",
                maxHeight: 650,
                objectFit: "contain"
              }}
              initial={{ x: 80, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: .8 }}
            />

          </Grid>

        </Grid>

      </Container>
    </Box>
  );
}